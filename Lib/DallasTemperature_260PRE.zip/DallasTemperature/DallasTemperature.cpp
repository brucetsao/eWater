// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.

#include "DallasTemperature.h"

extern "C" {
#include <string.h>
#include <stdlib.h>
#include "WConstants.h"
}

#define DS18S20MODEL 0x10	// Model ID
#define DS18B20MODEL 0x28	// Model ID
#define DS1822MODEL 0x22	// Model ID

#define STARTCONVO 0x44		// Tells device to take a temperature reading and put it on the scratchpad
#define COPYSCRATCH 0x48 	// Copy EEPROM
#define READSCRATCH 0xBE 	// Read EEPROM
#define WRITESCRATCH 0x4E 	// Write to EEPROM
#define RECALLSCRATCH 0xB8 	// Reload from last known
#define READPOWERSUPPLY 0xB4	// Determine if device needs parasite power
#define ALARMSEARCH 0xEC	// Determine if any devices experienced an alarm condition 
				// during the most recent temperature conversion

// device resolution
#define TEMP_9_BIT  0x1F //  9 bit
#define TEMP_10_BIT 0x3F // 10 bit
#define TEMP_11_BIT 0x5F // 11 bit
#define TEMP_12_BIT 0x7F // 12 bit

// Slave validation
#define INVALIDCRC 1
#define INVALIDMODEL 2
#define SLAVEGOOD 0

DallasTemperature::DallasTemperature(NewOneWire &oneWire, uint8_t index) :
    pDataWire(oneWire),
    index(index)
{
}

// read length bytes of a device's scratch pad
void DallasTemperature::readScratchPad(uint8_t length)
{
   // something we can read into and then ignore 
   uint8_t dump;

   // sanity check
   if (length > 8) length = 8;

   // send the command
   pDataWire.reset();
   pDataWire.select(arSlaveAddr);
   pDataWire.write(READSCRATCH);

   // read the response   
   for (uint8_t i = 0; i <= length; i++)
   switch (i)
   {
      case 0: 
         // byte 0: temperature LSB
         tempLSB = pDataWire.read();
	 break;
      case 1:
	 // byte 1: temperature MSB
	 tempMSB = pDataWire.read();
	 break;
      case 2:
	 // byte 2: high alarm temp
         highAlarmTemp = pDataWire.read();
	 break;
      case 3:
	 // byte 3: low alarm temp
	 lowAlarmTemp = pDataWire.read();
	 break;
      case 4:
	 // byte 4:
	 // The DS18S20 uses this bit internally while the other models
	 // use it as the configuration register
	 if (arSlaveAddr[0] != DS18S20MODEL)
	 {
	    // this is really the configuration register, but for 
	    // our purposes, this is how we'll think of it
	    resolution = pDataWire.read();
	 }
	 else
	 {
            // this bit can be ignored
            dump = pDataWire.read();
         }
         break;
      case 5:
	 // byte 5:
	 // internal use
	 dump = pDataWire.read();
	 break;
      case 6:
	 // byte 6:
	 if (arSlaveAddr[0] == DS18S20MODEL)
	 {
            // DS18S20: COUNT_REMAIN
            countRemain = pDataWire.read();
	 }
	 else
	 {
            // this bit can be ignored
            dump = pDataWire.read();
         }
	 break;
      case 7:
	 // byte 7:
	 if (arSlaveAddr[0] == DS18S20MODEL)
	 {
            // DS18S20: COUNT_PER_C
            countPerC = pDataWire.read();
	 }
	 else
	 {
            // this bit can be ignored
            dump = pDataWire.read();
         }
	 break;
      case 8:
         // byte 8:
	 // CRC
	 crc = pDataWire.read();
	 break;
   }
   pDataWire.reset();
}

// writes scratch pad for device
void DallasTemperature::writeScratchPad(void)
{
   pDataWire.reset();
   pDataWire.select(arSlaveAddr);
   pDataWire.write(WRITESCRATCH);
   pDataWire.write(highAlarmTemp); // the high alarm temp
   pDataWire.write(lowAlarmTemp); // the low alarm temp
   // DS18S20 does not use the configuration register
   if (arSlaveAddr[0] != DS18S20MODEL)
   {
      pDataWire.write(resolution); // configuration which is basically the resolution
   }
   pDataWire.reset();
   // save the newly written values to eeprom
   pDataWire.write(COPYSCRATCH, parasite);
   if (parasite) delay(10); // 10ms delay 
   pDataWire.reset();
}

// reads the device's power requirements
void DallasTemperature::readPowerSupply(void)
{
   pDataWire.reset();
   pDataWire.select(arSlaveAddr);
   pDataWire.write(READPOWERSUPPLY);
   if (pDataWire.read_bit()) parasite = 0; // pulled high so externally powered
   else parasite = 1; // pulled low so it is using parasite power
   pDataWire.reset();
}

// Start the interface with a new instance of NewOneWire
void DallasTemperature::begin()
{
    autoRequest = true;
    reset();
}

// Validate whether the current address is correct
int DallasTemperature::isValid(void)
{
    // Calculate Cycle-Redudancy-Check (ie: check the data is not invalid
    if (NewOneWire::crc8(arSlaveAddr, 7) != arSlaveAddr[7]) {
        return INVALIDCRC;
    }

    if (!(arSlaveAddr[0] == DS18B20MODEL ||
          arSlaveAddr[0] == DS18S20MODEL ||
          arSlaveAddr[0] == DS1822MODEL
       ))
    {
        return INVALIDMODEL;
    }

    // Return all good
    return SLAVEGOOD;

}

// Fires a total reset (Useful for intermittant connections)
void DallasTemperature::reset(void)
{
   // initialize internal variables
   highAlarmTemp = 0x07D0; // +125 C
   lowAlarmTemp = 0xFC90;  // -55 C
   resolution = TEMP_9_BIT; 
   parasite = 1;
   countRemain = 0x0C; // DS18S20 specific.  See p.7 of datasheet
   countPerC = 0x10; // DS18S20 specific.  See p.7 of datasheet

   // init array
   for(int i=0;i<8;i++) arSlaveAddr[i] = 0xFF;

   // find the device on the wire
   uint8_t depth = 0;
   pDataWire.reset_search();
   while (depth <= index && pDataWire.search(arSlaveAddr)) {
      if (isValid() == SLAVEGOOD)
         depth++;
   }
    
   // populate the local variables with the device's scratchpad data
   readPowerSupply();
   readScratchPad(8); // Read full scratch pad: byte 0 - byte 8
}

// returns a float with the temperature in degrees C.
float DallasTemperature::getTemperature()
{
    // If we're ready to rock, begin communication channel
    if (isValid() != SLAVEGOOD) return 0;  // return a value outside our range

   // you can send the convert request to all devices on the 
   // same bus so you can read them all after the conversion 
   // delay
   if (autoRequest) 
   {
      pDataWire.reset();
      pDataWire.select(arSlaveAddr);
      pDataWire.write(STARTCONVO, parasite); // start conversion
      conversionDelay();
   }

    if (arSlaveAddr[0] == DS18S20MODEL)
    {
	// DS18S20:
        // This is a high resolution model, so we can assume the temperature
	// returned should be as high-res as possible.  Unfortunately this requires 
	// reading the entire scratchpad.  it seems the COUNT_PER_C register doesn't 
	// change.  If the COUNT_REMAIN register doesn't change, then we can just 
	// read the values that were set when we initialized the device and go back to
	// only reading 2 bytes from the scratchpad.  Unfortunately I don't have a 
	// DS18S20 to test with and I can't seem to extract this info from the datasheet.
	readScratchPad(7); // read through byte 7
    }
    else
    {
        // The temp is the first two bytes so just request those 2
        readScratchPad(2); // read through byte 2
    }

    int16_t rawTemperature = (((int16_t) tempMSB) << 8) | tempLSB;

    switch (arSlaveAddr[0]) {
        case DS18B20MODEL:
        case DS1822MODEL:
           switch (resolution)
            {
               case TEMP_12_BIT:
                  return (float)rawTemperature * 0.0625;
                  break;
               case TEMP_11_BIT:
                  return (float)(rawTemperature >> 1) * 0.125;
                  break;
               case TEMP_10_BIT:
                  return (float)(rawTemperature >> 2) * 0.25;
                  break;
               case TEMP_9_BIT:
                  return (float)(rawTemperature >> 3) * 0.5;
                  break;
            }
            break;
        case DS18S20MODEL:
/*

Resolutions greater than 9 bits can be calculated using the data from 
the temperature, COUNT REMAIN and COUNT PER �C registers in the 
scratchpad. Note that the COUNT PER �C register is hard-wired to 16 
(10h). After reading the scratchpad, the TEMP_READ value is obtained 
by truncating the 0.5�C bit (bit 0) from the temperature data. The 
extended resolution temperature can then be calculated using the 
following equation:

                                 COUNT_PER_C - COUNT_REMAIN
TEMPERATURE = TEMP_READ - 0.25 + --------------------------
                                         COUNT_PER_C
*/
//            return (float)rawTemperature * 0.5;
            return (float)((rawTemperature >> 1) - 0.25 + ((countPerC - countRemain) / countPerC)); 
	    break;
    }

}

// returns true if the device requires parasite power
bool DallasTemperature::parasitePower(void)
{
   if (parasite) return true;
   return false;
}

// delays an amount based ont he device's resolution to ensure the 
// conversion has had time to take place.
void DallasTemperature::conversionDelay(void)
{
   if (arSlaveAddr[0] == DS18S20MODEL)
   {
       // DS18S20 always requires a max of 750 ms
       delay(750);
   }
   else
   {
      switch (resolution)
      {
         case TEMP_9_BIT:
            delay(94);
            break;
         case TEMP_10_BIT:
            delay(188);
            break;
         case TEMP_11_BIT:
            delay(375);
            break;
         case TEMP_12_BIT:
         default:
            delay(750);
            break;
      }
   }
}

// returns the current resolution, 9-12
uint8_t DallasTemperature::getResolution(void)
{
   if (arSlaveAddr[0] == DS18S20MODEL) return 9; // this model has a fixed resolution

   readScratchPad(4); // read through byte 4
   switch (resolution)
   {
      case TEMP_9_BIT:
         return 9;
	 break;
      case TEMP_10_BIT:
	 return 10;
	 break;
      case TEMP_11_BIT:
	 return 11;
	 break;
      case TEMP_12_BIT:
	 return 12;
	 break;
   }
}

// set resolution of a device to 9, 10, 11, or 12 bits
void DallasTemperature::setResolution(uint8_t newResolution)
{
   // DS18S20 has a fixed 9-bit resolution
   if (arSlaveAddr[0] != DS18S20MODEL)
   {
      readScratchPad(4); // read through byte 4
      switch (newResolution)
      {
         case 9:
            resolution = TEMP_9_BIT;
            break;
         case 10:
            resolution = TEMP_10_BIT;
            break;
         case 11:
            resolution = TEMP_11_BIT;
            break;
         case 12:
         default:
            resolution = TEMP_12_BIT;
            break;
         }
         writeScratchPad();   
   }
}

// sends convert temperature to all devices on the NewOneWire connection.
// only one device on each bus needs to do this.  ideally, it should be 
// on your highest resolution device so if a delay is necessary, it will 
// be long enough  
void DallasTemperature::globalTempRequest()
{
    pDataWire.reset();
    pDataWire.skip();
    pDataWire.write(STARTCONVO, parasite);
}

// returns temperature in degrees C
float DallasTemperature::getTempC()
{
    return getTemperature();
}

// returns temperature in degrees F
float DallasTemperature::getTempF()
{
    return toFahrenheit(getTemperature());
}

/*

TH and TL Register Format

BIT 7 BIT 6 BIT 5 BIT 4 BIT 3 BIT 2 BIT 1 BIT 0
  S    2^6   2^5   2^4   2^3   2^2   2^1   2^0

Only bits 11 through 4 of the temperature register are used 
in the TH and TL comparison since TH and TL are 8-bit 
registers. If the measured temperature is lower than or equal 
to TL or higher than or equal to TH, an alarm condition exists 
and an alarm flag is set inside the DS18B20. This flag is 
updated after every temperature measurement; therefore, if the 
alarm condition goes away, the flag will be turned off after 
the next temperature conversion.

The master device can check the alarm flag status of all DS18B20s 
on the bus by issuing an Alarm Search [ECh] command. Any DS18B20s 
with a set alarm flag will respond to the command, so the master can
determine exactly which DS18B20s have experienced an alarm condition. 
If an alarm condition exists and the TH or TL settings have changed, 
another temperature conversion should be done to validate the alarm 
condition.
 
*/

// sets the high alarm temperature for a device in degrees celsius
// accepts a float, but the alarm resolution will ignore anything 
// after a decimal point.  valid range is -55C - 125C
void DallasTemperature::setHighAlarmTemp(char celsius)
{
   // make sure the alarm temperature is withing the devices range
   if (celsius > 125) celsius = 125;
   else if (celsius < -55) celsius = -55;
   highAlarmTemp = (uint8_t)celsius;
   writeScratchPad();
}

// sets the low alarm temperature for a device in degreed celsius
// accepts a float, but the alarm resolution will ignore anything 
// after a decimal point.  valid range is -55C - 125C
void DallasTemperature::setLowAlarmTemp(char celsius)
{
   // make sure the alarm temperature is withing the devices range
   if (celsius > 125) celsius = 125;
   else if (celsius < -55) celsius = -55;
   lowAlarmTemp = (uint8_t)celsius;
   writeScratchPad();
}

// returns a float with the current high alarm temperature for a device
char DallasTemperature::getHighAlarmTemp()
{
   return (char)highAlarmTemp;
}

// returns a float with the current low alarm temperature for a device
char DallasTemperature::getLowAlarmTemp()
{
   return (char)lowAlarmTemp;
}

// searches the wire to determine if this device has raised an alarm
// this shouldn't be done per device.  ideally we'd just check the wire and return a 
bool DallasTemperature::hasAlarm()
{
   // find the device on the wire
   pDataWire.resetAlarmSearch();

   uint8_t flag = 0;
   uint8_t tmpAddress[8];

   while (pDataWire.alarmSearch(tmpAddress))
   {
      flag = 0;
      uint8_t i = 0;
      for (i = 0; i < 9; i++)
         if (tmpAddress[i] == arSlaveAddr[i]) flag++;
      if (flag == 8) return true; // all bytes matched
   }
   return false; 
}

// Convert float celsius to fahrenheit
float DallasTemperature::toFahrenheit(float celsius)
{
    return (celsius * 1.8) + 32;
}

// Convert float fahrenheit to celsius
float DallasTemperature::toCelsius(float fahrenheit)
{
    return (fahrenheit - 32) / 1.8;
}

// MnetCS - Allocates memory for DallasTemperature. Allows us to instance a new object
void* DallasTemperature::operator new(unsigned int size) // Implicit NSS obj size
{
  void * p; // void pointer
  p = malloc(size); // Allocate memory
  memset((DallasTemperature*)p,0,size); // Initalise memory

  //!!! CANT EXPLICITLY CALL CONSTRUCTOR - workaround by using an init() methodR - workaround by using an init() method
  return (DallasTemperature*) p; // Cast blank region to NSS pointer
}

// MnetCS 2009 -  Unallocates the memory used by this instance
void DallasTemperature::operator delete(void* p)
{
  DallasTemperature* pNss =  (DallasTemperature*) p; // Cast to NSS pointer
  pNss->~DallasTemperature(); // Destruct the object

  free(p); // Free the memory
}
