#ifndef DallasTemperature_h
#define DallasTemperature_h

// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.

#include <inttypes.h>

#include "NewOneWire.h"

// Strategies to calculate tempreture for specific device
#include "StratBase.h" // Base Strategy
#include "BSeries.h"   // Concrete Strat for 'b' series
#include "S20Series.h" // Concrete strat for S and '20' series
// The measurement we're taking

class DallasTemperature
{
    private:
    uint8_t arSlaveAddr[8];    // 64bit address of device

    NewOneWire &pDataWire;          // One Wire Instance

    // Find the nth temp sensor.
    void searchWire();

    // Send request temperature command
    void requestTemperature();

    // initalise arrays
    void initArr();

    // Initalise 1-wire communication
    void beginCommunication();

    // Pointer to temperature strategy
    StratBase* pStratBase;

    // Which temp sensor on the bus this instance talks to.
    uint8_t index;

    // Load appropriate strat
    int loadStrategy(); // Returns invalid model or good [-1]

    public:
    DallasTemperature(NewOneWire &oneWire, uint8_t index = 0, StratBase* pTBase = 0);

    // Process temperature in given format (default is C*)
    float getTemperature();
    uint8_t getIndex() const { return index; }

    // Initalise.
    void begin();

    // is the slave valid
    int isValid(); // strangely, 0 is "GOOD"

    // reset everything. Useful if you knock the power cable etc
    void reset();

    // Convert from celcius to farenheit if required
    static float toFahrenheit(float);

    void* operator new (unsigned int size); // Initalise memory area
    void operator delete(void* p); // delete memory reference

    const uint8_t *getSlaveAddr() const { return arSlaveAddr; }
};
#endif
