/*
	NewOneWire.cpp - Dallas Temperature Control Library 1.0.0
 	Author: Miles Burton, miles@mnetcs.com
        Website: http://milesburton.com/wiki
 	Copyright (c) 2009 Miles Burton All Rights Reserved

 	This library is free software; you can redistribute it and/or
 	modify it under the terms of the GNU Lesser General Public
 	License as published by the Free Software Foundation; either
 	version 2.1 of the License, or (at your option) any later version.

 	This library is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 	Lesser General Public License for more details.

 	You should have received a copy of the GNU Lesser General Public
 	License along with this library; if not, write to the Free Software
 	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

 	This code has been derived from: http://www.arduino.cc/playground/Learning/OneWire. Unknown author, unknown date

    This class extends the OneWire library to enable the new/delete operator for dynamic instantiation
 */


#include "NewOneWire.h"

extern "C" {
#include <string.h>
#include <stdlib.h>
#include "WConstants.h"
}


NewOneWire::NewOneWire(uint8_t pin) : OneWire(pin)
{

}

// resets the variables used when searching for alarms
void NewOneWire::resetAlarmSearch()
{
    uint8_t i;
    
    newSearchJunction = -1;
    newSearchExhausted = 0;
    for(i = 7; ; i--) {
	newSearchAddress[i] = 0;
	if (i == 0) break;
    }
}

// modified the OneWire search method.  I think it would be nice if 
// we could just pass the search command to that method.  also added 
// the OneWire search fix documented here:
// http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1238032295
uint8_t NewOneWire::alarmSearch(uint8_t *newAddr)
{
    uint8_t i;
    char lastJunction = -1;
    uint8_t done = 1;
    
    if (newSearchExhausted) return 0;
    
    if (!reset()) return 0;
    // send the alarm search command instead of the search command
    write(0xEC, 0);
    
    for(i = 0; i < 64; i++) {
	uint8_t a = read_bit( );
	uint8_t nota = read_bit( );
	uint8_t ibyte = i / 8;
	uint8_t ibit = 1 << (i & 7);
	
	// I don't think this should happen, this means nothing responded, but maybe if
	if (a && nota) return 0;  

	// something vanishes during the search it will come up.
	if (!a && !nota) 
	{
	    if (i == newSearchJunction)
	    { // this is our time to decide differently, we went zero last time, go one.
		a = 1;
		newSearchJunction = lastJunction;
	    } 
	    else if (i < newSearchJunction) 
	    { // take whatever we took last time, look in address
		if (newSearchAddress[ibyte] & ibit) a = 1;
		else 
		{ // Only 0s count as pending junctions, we've already exhasuted the 0 side of 1s
		    a = 0;
		    done = 0;
		    lastJunction = i;
		}
	    }
	    else
	    { // we are blazing new tree, take the 0
		a = 0;
		newSearchJunction = i;
		done = 0;
	    }
	    // search fix
	    // See: http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1238032295
	    // lastJunction = i;
	}
	if (a) newSearchAddress[ibyte] |= ibit;
	else newSearchAddress[ibyte] &= ~ibit;
	
	write_bit(a);
    }
    if (done) newSearchExhausted = 1;
    for (i = 0; i < 8; i++) newAddr[i] = newSearchAddress[i];
    return 1;  
}

// MnetCS - Allocates memory for NewSoftSerial. Allows us to instance a new object
void* NewOneWire::operator new(unsigned int size) // Implicit NSS obj size
{
  void * p; // void pointer
  p = malloc(size); // Allocate memory
  memset((NewOneWire*)p,0,size); // Initalise memory

  //!!! CANT EXPLICITLY CALL CONSTRUCTOR - workaround by using an init() methodR - workaround by using an init() method
  return (NewOneWire*) p; // Cast blank region to NSS pointer
}

// MnetCS 2009 -  Unallocates the memory used by this instance
void NewOneWire::operator delete(void* p)
{
  NewOneWire* pNss =  (NewOneWire*) p; // Cast to NSS pointer
  pNss->~NewOneWire(); // Destruct the object

  free(p); // Free the memory
}

