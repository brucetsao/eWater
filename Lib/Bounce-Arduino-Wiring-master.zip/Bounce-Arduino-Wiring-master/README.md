BOUNCE
=====================

Debouncing library for Arduino or Wiring
by Thomas Ouellet Fredericks
with contributions from:
Eric Lowry, Jim Schimpf and Tom Harkaway

DOWNLOAD
=====================

Download the latest version here : https://github.com/thomasfredericks/Bounce-Arduino-Wiring/archive/master.zip

DOCUMENTATION
=====================

The documentation can be found here : https://github.com/thomasfredericks/Bounce-Arduino-Wiring/wiki

